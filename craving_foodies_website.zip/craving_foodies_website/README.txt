# Craving Foodies — Free Website Starter

This is a static, mobile-friendly website starter for Craving Foodies. It includes:
- Premium dark theme and responsive layout
- Menu categories and item cards
- Add-to-cart and WhatsApp order summary
- Contact number and planned hours
- Basic SEO metadata

## Important before publishing
1. Check every menu item, price, description, operating hour and delivery area.
2. All food illustrations are emoji placeholders, not real food photographs. Replace them with your own food photos for a more authentic brand.
3. The current menu is based on the menu/prices supplied so far. Add vegetarian items when you finalize them.
4. The WhatsApp order button uses `+91 8887052718`.
5. The page prepares a WhatsApp message only. It does not accept payment or automatically confirm an order.
6. Google indexing and ranking are not guaranteed.

## Publish for free using GitHub Pages
1. Create/sign in to a free GitHub account at https://github.com/
2. Create a new public repository named `craving-foodies`.
3. Upload `index.html` to the repository's root.
4. Open repository Settings → Pages.
5. Under Build and deployment, select Deploy from a branch; choose `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. The free address is usually `https://YOUR-USERNAME.github.io/craving-foodies/`.
7. Test the site on your phone and test the WhatsApp order button.

Alternative: Cloudflare Pages can also host static websites on a free plan. Check the current provider terms and limits before publishing.
